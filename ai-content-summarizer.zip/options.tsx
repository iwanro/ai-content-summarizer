import { useState, useEffect } from "react"
import { Storage } from "@plasmohq/storage"
import "~style.css"

const storage = new Storage()

function OptionsIndex() {
    const [apiKey, setApiKey] = useState("")
    const [provider, setProvider] = useState("deepseek")
    const [isPro, setIsPro] = useState(false)
    const [status, setStatus] = useState("")

    useEffect(() => {
        const loadSettings = async () => {
            const savedKey = await storage.get("api_key")
            const savedProvider = await storage.get("api_provider")
            const savedPro = await storage.get("is_pro")
            if (savedKey) setApiKey(savedKey as string)
            if (savedProvider) setProvider(savedProvider as string)
            if (savedPro === true || savedPro === "true") setIsPro(true)
        }
        loadSettings()
    }, [])

    const saveOptions = async () => {
        await storage.set("api_key", apiKey)
        await storage.set("api_provider", provider)
        await storage.set("is_pro", isPro)
        setStatus("Options saved!")
        setTimeout(() => setStatus(""), 2000)
    }

    return (
        <div className="p-8 w-[500px] mx-auto">
            <h1 className="text-2xl font-bold mb-4">AI Content Summarizer Settings</h1>

            <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">AI Provider</label>
                <div className="flex gap-4">
                    <label className="flex items-center">
                        <input
                            type="radio"
                            name="provider"
                            value="deepseek"
                            checked={provider === "deepseek"}
                            onChange={(e) => setProvider(e.target.value)}
                            className="mr-2"
                        />
                        DeepSeek
                    </label>
                    <label className="flex items-center">
                        <input
                            type="radio"
                            name="provider"
                            value="gemini"
                            checked={provider === "gemini"}
                            onChange={(e) => setProvider(e.target.value)}
                            className="mr-2"
                        />
                        Google Gemini
                    </label>
                </div>
            </div>

            <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">
                    {provider === "deepseek" ? "DeepSeek" : "Gemini"} API Key
                </label>
                <input
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
                    placeholder="Enter your API Key"
                />
                <p className="text-xs text-gray-500 mt-1">
                    {provider === "deepseek" ? (
                        <>Get your key from <a href="https://platform.deepseek.com/" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">DeepSeek Platform</a>.</>
                    ) : (
                        <>Get your key from <a href="https://aistudio.google.com/" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">Google AI Studio</a>.</>
                    )}
                </p>
            </div>

            <div className="mb-4 flex items-center">
                <input
                    id="is-pro"
                    type="checkbox"
                    checked={isPro}
                    onChange={(e) => setIsPro(e.target.checked)}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <label htmlFor="is-pro" className="ml-2 block text-sm text-gray-900">
                    Simulate Pro Plan (Unlimited)
                </label>
            </div>

            <button
                onClick={saveOptions}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
                Save Options
            </button>

            {status && <div className="mt-4 text-green-600">{status}</div>}
        </div>
    )
}

export default OptionsIndex
