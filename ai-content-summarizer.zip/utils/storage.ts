import { Storage } from "@plasmohq/storage"

const storage = new Storage()

export const STORAGE_KEYS = {
    DAILY_USAGE: "daily_usage",
    LAST_RESET: "last_reset",
    IS_PRO: "is_pro",
    API_KEY: "api_key",
    API_PROVIDER: "api_provider"
}

export const getDailyUsage = async (): Promise<number> => {
    const usage = await storage.get(STORAGE_KEYS.DAILY_USAGE)
    return usage ? parseInt(usage) : 0
}

export const incrementUsage = async (): Promise<number> => {
    const current = await getDailyUsage()
    const newValue = current + 1
    await storage.set(STORAGE_KEYS.DAILY_USAGE, newValue.toString())
    return newValue
}

export const checkAndResetDailyUsage = async () => {
    const lastReset = await storage.get(STORAGE_KEYS.LAST_RESET)
    const today = new Date().toDateString()

    if (lastReset !== today) {
        await storage.set(STORAGE_KEYS.DAILY_USAGE, "0")
        await storage.set(STORAGE_KEYS.LAST_RESET, today)
    }
}

export const isProUser = async (): Promise<boolean> => {
    const isPro = await storage.get(STORAGE_KEYS.IS_PRO)
    return isPro === true || isPro === "true"
}

export const getApiKey = async (): Promise<string> => {
    return await storage.get(STORAGE_KEYS.API_KEY) || ""
}

export const getApiProvider = async (): Promise<string> => {
    return await storage.get(STORAGE_KEYS.API_PROVIDER) || "deepseek"
}
