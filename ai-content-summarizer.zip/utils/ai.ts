import { getApiKey, getApiProvider } from "./storage"

export const summarizeContent = async (content: string): Promise<string> => {
    const apiKey = await getApiKey()
    const provider = await getApiProvider()

    if (!apiKey) {
        throw new Error("API Key is missing. Please set it in the extension options.")
    }

    const prompt = `Please summarize the following content in a concise and easy-to-understand way. Use bullet points if appropriate. 

IMPORTANT: Provide the summary in the SAME LANGUAGE as the original content below. If the content is in Romanian, respond in Romanian. If it's in English, respond in English, etc.

Content:
${content}`

    if (provider === "deepseek") {
        return await callDeepSeek(apiKey, prompt)
    } else {
        return await callGemini(apiKey, prompt)
    }
}

async function callDeepSeek(apiKey: string, prompt: string): Promise<string> {
    const response = await fetch("https://api.deepseek.com/chat/completions", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            model: "deepseek-chat",
            messages: [
                {
                    role: "system",
                    content: "You are a helpful assistant that summarizes content clearly and concisely. Always respond in the SAME LANGUAGE as the input text. Never translate."
                },
                { role: "user", content: prompt }
            ],
            stream: false
        })
    })

    if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error?.message || "DeepSeek API error")
    }

    const data = await response.json()
    return data.choices[0].message.content
}

async function callGemini(apiKey: string, prompt: string): Promise<string> {
    const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${apiKey}`

    const response = await fetch(API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            contents: [{
                parts: [{ text: prompt }]
            }],
            systemInstruction: {
                parts: [{
                    text: "You are a text summarization expert. Always respond in the SAME LANGUAGE as the input text. Never translate to English or any other language."
                }]
            }
        })
    })

    if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error?.message || "Gemini API error")
    }

    const data = await response.json()
    return data.candidates[0].content.parts[0].text
}
