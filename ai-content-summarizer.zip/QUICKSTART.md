# AI Content Summarizer - Quick Start Guide

## 🎯 For Users

### Installation Steps

1. **Download the extension**
   - Go to the [Releases page](../../releases)
   - Download the latest `.zip` file
   - Extract it to a folder

2. **Load in Chrome**
   - Open `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked"
   - Select the extracted folder

3. **Setup**
   - Click extension icon → Settings (gear icon)
   - Choose AI provider: **DeepSeek** (cheaper) or **Gemini**
   - Get API key:
     - DeepSeek: https://platform.deepseek.com/
     - Gemini: https://aistudio.google.com/
   - Paste API key and save

4. **Use**
   - Go to any webpage
   - Click extension icon
   - Click "Summarize Page"
   - Done! 🎉

### Free vs Pro

- **Free**: 5 summarizations/day (resets daily)
- **Pro**: Unlimited (toggle in settings for testing)

---

## 👨‍💻 For Developers

### Quick Setup

```bash
# Clone repository
git clone https://github.com/yourusername/ai-content-summarizer.git
cd ai-content-summarizer

# Install dependencies
pnpm install

# Start development server
pnpm dev

# Load extension from build/chrome-mv3-dev
```

### Build Commands

```bash
pnpm dev      # Development with hot reload
pnpm build    # Production build
pnpm package  # Create distribution package
```

### Key Files

- `popup.tsx` - Main popup UI
- `options.tsx` - Settings page
- `utils/ai.ts` - AI provider integration
- `utils/storage.ts` - Storage & user management
- `content.ts` - Content extraction script

### Testing

1. Make changes to source files
2. Extension auto-rebuilds (dev mode)
3. Reload extension in Chrome Extensions page
4. Test on a webpage

---

## 🔑 Getting API Keys

### DeepSeek (Recommended - Cheaper)
1. Visit https://platform.deepseek.com/
2. Sign up/Login
3. Go to API Keys section
4. Create new key
5. Copy and paste in extension settings

### Google Gemini
1. Visit https://aistudio.google.com/
2. Login with Google account
3. Click "Get API Key"
4. Create in new/existing project
5. Copy and paste in extension settings

---

## ❓ Troubleshooting

### "Could not extract text from this page"
- Some pages block content scripts
- Try a different page

### "Free limit reached"
- You've used 5 summaries today
- Wait until tomorrow for reset
- OR enable Pro mode in settings

### "API Error"
- Check your API key is correct
- Ensure you have credits in your AI provider account
- Check browser console (F12) for details

### Extension not loading
- Make sure you selected the correct folder (`build/chrome-mv3-dev` or `build/chrome-mv3-prod`)
- Try refreshing the extension
- Rebuild: `pnpm build`

---

## 📞 Need Help?

- Check the [full README](README.md)
- Open an [issue on GitHub](../../issues)
- Review the code - it's well-documented!

---

**Happy Summarizing! 🚀**
