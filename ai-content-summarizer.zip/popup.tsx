import { useState, useEffect } from "react"
import { summarizeContent } from "~utils/ai"
import { checkAndResetDailyUsage, getDailyUsage, incrementUsage, isProUser } from "~utils/storage"
import "~style.css"

function IndexPopup() {
  const [loading, setLoading] = useState(false)
  const [summary, setSummary] = useState("")
  const [error, setError] = useState("")
  const [usage, setUsage] = useState(0)
  const [isPro, setIsPro] = useState(false)

  useEffect(() => {
    checkAndResetDailyUsage()
    loadUserData()
  }, [])

  const loadUserData = async () => {
    const currentUsage = await getDailyUsage()
    const proStatus = await isProUser()
    setUsage(currentUsage)
    setIsPro(proStatus)
  }

  const handleSummarize = async () => {
    setError("")
    setSummary("")
    setLoading(true)

    try {
      if (!isPro && usage >= 5) {
        throw new Error("Free limit reached (5/5). Please upgrade to Pro.")
      }

      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

      if (!tab.id) {
        throw new Error("Could not access current tab.")
      }

      const response = await chrome.tabs.sendMessage(tab.id, { action: "GET_TEXT" })

      if (!response || !response.text) {
        throw new Error("Could not extract text from this page.")
      }

      const result = await summarizeContent(response.text)
      setSummary(result)

      if (!isPro) {
        await incrementUsage()
        await loadUserData()
      }

    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const openOptions = () => {
    chrome.runtime.openOptionsPage()
  }

  return (
    <div className="w-[400px] p-4 bg-slate-50 min-h-[300px] flex flex-col">
      <header className="flex justify-between items-center mb-4 border-b pb-2">
        <h1 className="text-xl font-bold text-indigo-700">AI Summarizer</h1>
        <button onClick={openOptions} className="text-gray-500 hover:text-indigo-600">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.212 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z" />
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </button>
      </header>

      <div className="flex-1 flex flex-col gap-4">
        {!isPro && (
          <div className="bg-orange-100 text-orange-800 px-3 py-1 rounded text-sm flex justify-between items-center">
            <span>Free Plan</span>
            <span className="font-bold">{5 - usage} credits left</span>
          </div>
        )}

        {isPro && (
          <div className="bg-green-100 text-green-800 px-3 py-1 rounded text-sm flex justify-between items-center">
            <span className="font-bold">Pro Plan (Unlimited)</span>
          </div>
        )}

        <button
          onClick={handleSummarize}
          disabled={loading || (!isPro && usage >= 5)}
          className={`w-full py-2 rounded-lg font-medium text-white transition-colors ${loading ? "bg-indigo-400 cursor-wait" :
            (!isPro && usage >= 5) ? "bg-gray-400 cursor-not-allowed" :
              "bg-indigo-600 hover:bg-indigo-700"
            }`}
        >
          {loading ? "Summarizing..." : "Summarize Page"}
        </button>

        {error && (
          <div className="p-3 bg-red-100 text-red-700 rounded text-sm">
            {error}
          </div>
        )}

        {summary && (
          <div className="flex-1 bg-white border rounded-lg p-3 text-sm text-gray-700 overflow-y-auto max-h-[300px] shadow-sm">
            <h3 className="font-bold mb-2 text-gray-900">Summary:</h3>
            <div className="prose prose-sm">
              {summary.split('\n').map((line, i) => (
                <p key={i} className="mb-1">{line}</p>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 text-center text-xs text-gray-400">
        Powered by Gemini AI
      </div>
    </div>
  )
}

export default IndexPopup
