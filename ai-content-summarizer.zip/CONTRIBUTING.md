# Contributing to AI Content Summarizer

First off, thank you for considering contributing to AI Content Summarizer! 🎉

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check existing issues. When creating a bug report, include:

- **Clear title** and description
- **Steps to reproduce** the behavior
- **Expected behavior**
- **Screenshots** if applicable
- **Environment details** (Chrome version, OS, etc.)

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, include:

- **Clear title** and detailed description
- **Use case** - why would this be useful?
- **Possible implementation** if you have ideas

### Pull Requests

1. Fork the repo and create your branch from `main`
2. If you've added code, add tests if applicable
3. Ensure the code builds successfully (`pnpm build`)
4. Make sure your code follows the existing style
5. Write a clear commit message
6. Push to your fork and submit a pull request

## Development Setup

```bash
# Fork and clone
git clone https://github.com/YOUR-USERNAME/ai-content-summarizer.git
cd ai-content-summarizer

# Install dependencies
pnpm install

# Start development
pnpm dev
```

## Code Style

- Use TypeScript
- Follow existing code formatting (Prettier is configured)
- Use meaningful variable names
- Add comments for complex logic
- Keep functions small and focused

## Commit Messages

- Use present tense ("Add feature" not "Added feature")
- Use imperative mood ("Move cursor to..." not "Moves cursor to...")
- Reference issues and pull requests when relevant

## Questions?

Feel free to open an issue with your question!

Thank you! ❤️
